package com.cs309.WebSocketsExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebSocketsExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
