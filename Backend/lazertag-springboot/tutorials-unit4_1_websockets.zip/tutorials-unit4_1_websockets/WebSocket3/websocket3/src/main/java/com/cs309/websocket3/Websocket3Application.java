package com.cs309.websocket3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Websocket3Application {

	public static void main(String[] args) {
		SpringApplication.run(Websocket3Application.class, args);
	}

}
