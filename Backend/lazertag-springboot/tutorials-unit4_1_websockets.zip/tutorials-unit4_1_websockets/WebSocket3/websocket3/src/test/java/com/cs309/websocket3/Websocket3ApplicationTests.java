package com.cs309.websocket3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Websocket3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
